create database Crime_Record_Management;
use Crime_Record_Management;
create table Guard_Info(
Guard_id varchar(20) not null,
First_name varchar(20) not null,
Last_name varchar(20) not null,
Gender varchar(10) not null,
DOB date not null,
Age int not null,
Address varchar(200) not null,
Phone_no varchar(20) not null,
Alternate_phone_no varchar(20) null,
Shift_timing varchar(20) not null,
Position varchar(100) not null,
Prison_id varchar(20) not null,
foreign key(prison_id) references Prison_Info(Prison_id)
); 

select* from Guard_Info;


