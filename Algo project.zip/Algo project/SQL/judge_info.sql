use Crime_Record_Management;
create table Judge_Info(
Judge_id varchar(10) not null,
Judge_age int not null,
First_name varchar(20) not null,
Last_name varchar(20) null,
Designation varchar(50) not null,
Court_id varchar(20) not null,
primary key(Judge_id),
foreign key(Court_id) references Court_Info(Court_id)
);

insert into crime_record_management.judge_info values("J101", 70, "ronald", "john", "senior judge", "CRT101");

insert into crime_record_management.judge_info values("J102", 40, "daksh", "tripathi", "senior judge", "CRT101");
insert into crime_record_management.judge_info values("J103", 55, "raanu", "lavsh", "senior judge", "CRT101");
insert into crime_record_management.judge_info values("J104", 65, "aaditya", "jain", "senior judge", "CRT102");
insert into crime_record_management.judge_info values("J105", 60, "prakash", "suthar", "senior judge", "CRT103");


select* from Judge_Info;
