use Crime_Record_Management;
create table Crime_Record_Management.Court_Info(
Court_id varchar(20) not null,
Court_name varchar(100) not null,
Court_address varchar(500) not null,
Court_level varchar(100) not null,
primary key(Court_id) 
); 

insert into crime_record_management.court_info values("CRT101", "queens court", "queens", "higher");

insert into crime_record_management.court_info values("CRT102", "queens court", "queens", "middle");
insert into crime_record_management.court_info values("CRT103", "queens court", "queens", "lower");


select* from Court_Info;