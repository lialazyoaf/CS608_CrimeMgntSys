use Crime_Record_Management;

create table Crime_Record_Management.Offender_Info(
Criminal_id varchar(10) not null,
First_name varchar(20) not null,
Last_name varchar(20) null,
Gender varchar(20) not null,
Age varchar(20) not null,
Nationality varchar(50) not null,
Address varchar(200) not null,
Phone_no varchar(20) not null,
Alternate_phone_no varchar(20) null,
Offense_type varchar(200) not null,
Bail_status varchar(20) not null,
Jail_terms varchar(50) not null,
Prison_location varchar(50) not null,
Prison_guard varchar(50) not null,
Victim_id varchar(20) not null,
Judge_id varchar(10) not null,
Court_id varchar(20) not null,
primary key(Criminal_id),
foreign key(Victim_id) references Victim_Info(Victim_id),
foreign key(Judge_id) references Judge_Info(Judge_id),
foreign key(Court_id) references Court_Info(Court_id) 
);

select* from Offender_Info;

insert into Crime_Record_Management.Offender_Info values("O101", "jash", "shah", "male", 22, "Indian","queens", "9219929345", " ", "murder", "jailed", "na", "queens", "daksh","V101", "J101", "CRT101");

insert into Crime_Record_Management.Offender_Info values("O102", "ravan", "patel", "male", 22, "Indian","brooklyn", "9232329345", " ", "theft", "jailed", "na", "brooklyn", "vyom","V101", "J102", "CRT102");
insert into Crime_Record_Management.Offender_Info values("O103", "niraj", "joshi", "male", 32, "American","queens", "9219929656", " ", "half murder", "jailed", "na", "queens", "fellipe","V102", "J101", "CRT101");
insert into Crime_Record_Management.Offender_Info values("O104", "alex", "john", "male", 25, "Brazilian","bronx", "9219976545", " ", "half murder", "jailed", "na", "bronx", "john","V101", "J104", "CRT103");
insert into Crime_Record_Management.Offender_Info values("O105", "alley", "ferrari", "male", 42, "Italian","manhattan", "9219929433", " ", "murder", "jailed", "na", "manhattan", "shrey","V105", "J101", "CRT103");




-- drop table Crime_Record_Management.Offender_Info;