use Crime_Record_Management;
create table Victim_Info(
Victim_id varchar(20) not null,
First_name varchar(50) not null,
Last_name varchar(50) not null,
age int,
Nationality varchar(50) not null,
Address varchar(200) not null,
Phone_no varchar(20) not null,
Alternate_phone_no varchar(20) null,
Judge_id varchar(10) not null,
Court_id varchar(20) not null,
primary key(Victim_id),
foreign key(Judge_id) references Judge_Info(Judge_id),
foreign key(Court_id) references Court_Info(Court_id) 
);


insert into crime_record_management.victim_info values("V101", "chandan", "yadav", 23, "American", "brookyln", "9992319526", " ", "J101", "CRT101");

insert into crime_record_management.victim_info values("V102", "chandan", "ganguli", 23, "Indian", "queens", "9992319112", " ", "J102", "CRT101");
insert into crime_record_management.victim_info values("V103", "shivani", "jadhav", 30, "American", "brookyln", "9993459526", " ", "J101", "CRT101");
insert into crime_record_management.victim_info values("V104", "raaj", "shah", 33, "African", "manhattan", "9956219526", " ", "J103", "CRT101");
insert into crime_record_management.victim_info values("V105", "jayant", "paal", 43, "Italian", "bronx", "9252319526", " ", "J104", "CRT102");

select * from Victim_Info;
