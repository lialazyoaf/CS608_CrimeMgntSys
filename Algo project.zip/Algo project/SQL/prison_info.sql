use Crime_Record_Management;
create table Prison_Info(
Prison_id varchar(20) not null,
Prison_name varchar(20) not null,
Phone_no varchar(20) not null,
Prison_address varchar(20) not null,
Criminal_id varchar(10) not null,
primary key(Prison_id),
foreign key(Criminal_id) references offender_Info(Criminal_id)
);

select * from Prison_Info;

SELECT * FROM Crime_Record_Management.Prison_Info;