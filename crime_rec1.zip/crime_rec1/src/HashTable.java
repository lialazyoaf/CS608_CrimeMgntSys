import java.util.LinkedList;

class KeyValuePair<K, V> {
    K key;
    V value;

    public KeyValuePair(K key, V value) {
        this.key = key;
        this.value = value;
    }
}

public class HashTable<K, V> {
    private static final int DEFAULT_CAPACITY = 10;
    private LinkedList<KeyValuePair<K, V>>[] table;
    private int size;

    public HashTable() {
        table = new LinkedList[DEFAULT_CAPACITY];
        size = 0;
    }

    // Hash function
    private int hashFunction(K key) {

        return Math.abs(key.hashCode() % table.length);
    }

    public void put(K key, V value) {
        int index = hashFunction(key);
        if (table[index] == null) {
            table[index] = new LinkedList<>();
        }


        for (KeyValuePair<K, V> pair : table[index]) {
            if (pair.key.equals(key)) {
                pair.value = value; // Update value if key exists
                return;
            }
        }

        table[index].add(new KeyValuePair<>(key, value));
        size++;
    }

    public V get(K key) {
        int index = hashFunction(key);
        if (table[index] != null) {
            for (KeyValuePair<K, V> pair : table[index]) {
                if (pair.key.equals(key)) {
                    return pair.value;
                }
            }
        }
        return null;
    }

    public void remove(K key) {
        int index = hashFunction(key);
        if (table[index] != null) {
            table[index].removeIf(pair -> pair.key.equals(key));
            size--;
        }
    }

    public int size() {
        return size;
    }

    public static void main(String[] args) {
        HashTable<String, Integer> hashTable = new HashTable<>();

        // Insertion
        hashTable.put("one", 1);
        hashTable.put("two", 2);
        hashTable.put("three", 3);

        // Search
        System.out.println("Val for key 'two': " + hashTable.get("two"));

        // Deletion
        hashTable.remove("two");

        // Search after deletion
        System.out.println("Val for key 'two' after deletion: " + hashTable.get("two"));

        // Print size
        System.out.println("Size of hash table: " + hashTable.size());
    }
}

