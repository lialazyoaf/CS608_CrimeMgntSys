import net.proteanit.sql.DbUtils;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class Punishment_Info {
    private JPanel main;
    private JButton btnupdate;
    private JButton btndelete;
    private JTextField textpid;
    private JTextField textfd;
    private JButton btnsave;
    private JButton btnsearch;
    private JTable table1;
    private JTextField textsearch;
    private JLabel pun_id;
    private JLabel From_date;
    private JLabel From_time;
    private JTextField textft;
    private JLabel To_date;
    private JTextField texttd;
    private JLabel To_time;
    private JTextField texttt;
    private JLabel Total_dur;
    private JTextField texttld;
    private JLabel Pun_des;
    private JTextField textpd;
    private JLabel Pun_inc;
    private JTextField textpin;
    private JLabel Reason_pun_inc;
    private JTextField textrpin;
    private JLabel Criminal_id;
    private JTextField textcrid;
    private JLabel Prison_id;
    private JTextField textprid;
    private JLabel Judge_id;
    private JTextField textjid;
    private JLabel Crime_id;
    private JTextField textcid;


    public static void main(String[] args) {
        JFrame frame = new JFrame("Punishment_Info");
        frame.setContentPane(new Punishment_Info().main);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }

    // database connection

    Connection conn;
    PreparedStatement pst;
    public void connect(){
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/Crime_Record_Management", "root", "Ansh@123");
            System.out.println("Success Mysql connection");
        }
        catch (ClassNotFoundException ex){
            System.out.println(ex);
        }
        catch (SQLException ex){
            System.out.println(ex);
        }

    }

    // to load data in ui table (method)
    void load_table(){
        try{
            pst = conn.prepareStatement("select* from Punishment_Info");
            ResultSet rs = pst.executeQuery();
            table1.setModel(DbUtils.resultSetToTableModel(rs)); // private JTable judge_table;
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }

    }

    // empty field method
    void emptyFields(){
        textpid.setText(" ");
        textfd.setText(" ");
        textft.setText(" ");
        texttd.setText(" ");
        texttt.setText(" ");
        texttd.setText(" ");
        textpd.setText(" ");
        textpin.setText(" ");
        textrpin.setText(" ");
        textcrid.setText(" ");
        textprid.requestFocus();
        textjid.requestFocus();
        textcid.requestFocus();
    }


    public Punishment_Info() {
        connect();
        load_table();
        btnsave.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // creating variables for storing inserting data
                String Pun_id, F_date, F_time, T_date, T_time, T_duration, Pun_des, Pun_inc, Reason_pun_inc, Cr_id, P_id, J_id, C_id;
                // assigning values to above created varibale from ui
                Pun_id = textpid.getText();
                F_date = textfd.getText();
                F_time = textft.getText();
                T_date = texttd.getText();
                T_time = texttt.getText();
                T_duration = texttld.getText();
                Pun_des = textpd.getText();
                Pun_inc = textpin.getText();
                Reason_pun_inc = textrpin.getText();
                Cr_id = textcrid.getText();
                P_id = textprid.getText();
                J_id = textjid.getText();
                C_id = textcid.getText();

                try{
                    //insert statement for sql
                    pst = conn.prepareStatement("insert into Punishment_Info(Punishment_id, From_date, From_time, To_date, To_time, Total_duration, Punishment_des, Punishment_inc, Reason_punishment_inc, Criminal_id, Prison_id, Judge_id, Crime_id) values(?,?,?,?,?,?,?,?,?,?,?,?,?)");
                    // assigning values to index number
                    pst.setString(1, Pun_id);
                    pst.setString(2, F_date);
                    pst.setString(3, F_time);
                    pst.setString(4, T_date);
                    pst.setString(5, T_time);
                    pst.setString(6, T_duration);
                    pst.setString(7, Pun_des);
                    pst.setString(8, Pun_inc);
                    pst.setString(9, Reason_pun_inc);
                    pst.setString(10, Cr_id);
                    pst.setString(11, P_id);
                    pst.setString(12, J_id);
                    pst.setString(13, C_id);
                    // to add records in db table
                    pst.executeUpdate();
                    //popup msg for added record
                    JOptionPane.showMessageDialog(null, "Record added !");
                    load_table();
                    emptyFields();
                }
                catch(SQLException e1){
                    e1.printStackTrace();
                }
            }
        });
        btnsearch.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{
                    // statement to search particular id's data
                    String id = textsearch.getText();
                    pst = conn.prepareStatement("select * from Punishment_Info where Punishment_id = ?");
                    pst.setString(1, id);
                    ResultSet rs = pst.executeQuery();

                    if(rs.next() == true){

                        // retrieve the data from table and assign it to variable
                        String Pun_id = rs.getString(1);
                        String From_date = rs.getString(2);
                        String From_time = rs.getString(3);
                        String To_date = rs.getString(4);
                        String To_time = rs.getString(5);
                        String Total_dur = rs.getString(6);
                        String Pun_des = rs.getString(7);
                        String Pun_inc = rs.getString(8);
                        String Reason_pun_inc = rs.getString(9);
                        String Criminal_id = rs.getString(10);
                        String Prison_id = rs.getString(11);
                        String Judge_id = rs.getString(12);
                        String Crime_id = rs.getString(13);

                        //to display the records in text field

                        textpid.setText(Pun_id);
                        textfd.setText(From_date);
                        textft.setText(From_time);
                        texttd.setText(To_date);
                        texttt.setText(To_time);
                        texttld.setText(Total_dur);
                        textpd.setText(Pun_des);
                        textpin.setText(Pun_inc);
                        textrpin.setText(Reason_pun_inc);
                        textcrid.setText(Criminal_id);
                        textprid.setText(Prison_id);
                        textjid.setText(Judge_id);
                        textcid.setText(Crime_id);

                    }
                    else{
                        emptyFields();
                        JOptionPane.showMessageDialog(null, "Invalid id selection !");
                    }
                }
                catch(SQLException ex){
                    ex.printStackTrace();
                }
            }
        });
        btnupdate.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String Pun_id, F_date, F_time, T_date, T_time, T_duration, Pun_des, Pun_inc, Reason_pun_inc, Cr_id, P_id, J_id, C_id;;
                // assigning values to above created varibale from ui
                Pun_id = textpid.getText();
                F_date = textfd.getText();
                F_time = textft.getText();
                T_date = texttd.getText();
                T_time = texttt.getText();
                T_duration = texttld.getText();
                Pun_des = textpd.getText();
                Pun_inc = textpin.getText();
                Reason_pun_inc = textrpin.getText();
                Cr_id = textcrid.getText();
                P_id = textprid.getText();
                J_id = textjid.getText();
                C_id = textcid.getText();


                try{
                    //statement to update the values
                    pst = conn.prepareStatement("update Punishment_Info set From_date = ?, From_time = ?, To_date = ?, To_time = ?, Total_duration = ?, Punishment_des = ?, Punishment_inc = ?, Reason_punishment_inc = ?, Criminal_id =?, Prison_id = ?, Judge_id = ?, Crime_id = ? where Punishment_id = ?");
                    System.out.println(pst);
                    System.out.println(pun_id);
                    // inserting column data of sql


                    pst.setString(1, F_date);
                    pst.setString(2, F_time);
                    pst.setString(3, T_date);
                    pst.setString(4, T_time);
                    pst.setString(5, T_duration);
                    pst.setString(6, Pun_des);
                    pst.setString(7, Pun_inc);
                    pst.setString(8, Reason_pun_inc);
                    pst.setString(9, Cr_id);
                    pst.setString(10, P_id);
                    pst.setString(11, J_id);
                    pst.setString(12, C_id);
                    pst.setString(13, Pun_id);

                    // to add records in db table
                    pst.executeUpdate();
                    JOptionPane.showMessageDialog(null,"Records updated !");
                    load_table();

                    emptyFields();
                }
                catch(SQLException ex){
                    ex.printStackTrace();
                }
            }
        });
        btndelete.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String pu_id;
                pu_id = textcrid.getText();

                try{
                    // statement to delete the record
                    pst = conn.prepareStatement("delete from Punishment_Info where Punishment_id = ?");
                    pst.setString(1, pu_id);
                    pst.executeUpdate();
                    JOptionPane.showMessageDialog(null,"Record deleted !");
                    load_table();
                    emptyFields();
                }
                catch(SQLException ex){
                    ex.printStackTrace();
                }
            }
        });
    }
}
