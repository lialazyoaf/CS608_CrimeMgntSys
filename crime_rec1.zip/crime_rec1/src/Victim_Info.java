import net.proteanit.sql.DbUtils;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class Victim_Info {
    private JPanel main;
    private JTextField textvid;
    private JTextField textfname;
    private JTextField textlname;
    private JTextField textage;
    private JTextField textnationality;
    private JTextField textadd;
    private JTextField textphno;
    private JTextField textaltphno;
    private JTextField textjid;
    private JTextField textcid;
    private JButton btnupdate;
    private JButton btndelete;
    private JButton btnsave;
    private JButton btnsearch;
    private JTable table1;
    private JLabel Victim_id;
    private JLabel First_name;
    private JLabel Last_name;
    private JLabel Age;
    private JLabel Nationality;
    private JLabel Add;
    private JLabel Phone_no;
    private JLabel Alt_phno;
    private JLabel Judge_id;
    private JLabel Court_id;
    private JTextField textsearch;

    public static void main(String[] args) {
        JFrame frame = new JFrame("Victim_Info");
        frame.setContentPane(new Victim_Info().main);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }

    // databasq connection

    Connection conn;
    PreparedStatement pst;
    public void connect(){
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/Crime_Record_Management", "root", "Ansh@123");
            System.out.println("Success Mysql connection");
        }
        catch (ClassNotFoundException ex){
            System.out.println(ex);
        }
        catch (SQLException ex){
            System.out.println(ex);
        }

    }

    // to load data in ui table (method)
    void load_table(){
        try{
            pst = conn.prepareStatement("select* from Victim_Info");
            ResultSet rs = pst.executeQuery();
            table1.setModel(DbUtils.resultSetToTableModel(rs)); // private JTable judge_table;
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }

    }

    //empty the fields from ui after insertion of data (method)

    void emptyFields(){
        textvid.setText(" ");
        textfname.setText(" ");
        textlname.setText(" ");
        textage.setText(" ");
        textnationality.setText(" ");
        textadd.setText(" ");
        textphno.setText(" ");
        textaltphno.setText(" ");
        textjid.setText(" ");
        textcid.setText(" ");
        textfname.requestFocus();
    }

    public Victim_Info() {
        connect();
        load_table();
        btnsave.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // creating variables for storing inserting data
                String vid, fname, lname, v_age, v_nationality, add, ph_no, alt_phno, jid, cid;
                // assigning values to above created varibale from ui
                vid = textvid.getText();
                fname = textfname.getText();
                lname = textlname.getText();
                v_age = textage.getText();
                v_nationality = textnationality.getText();
                add = textadd.getText();
                ph_no = textphno.getText();
                alt_phno = textaltphno.getText();
                jid = textjid.getText();
                cid = textcid.getText();

                try{
                    //insert statement for sql
                    pst = conn.prepareStatement("insert into Victim_Info(Victim_id, First_name, Last_name, age, nationality, Address, Phone_no, alternate_phone_no, Judge_id, Court_id) values(?,?,?,?,?,?,?,?,?,?)");
                    // assigning values to index number
                    pst.setString(1, vid);
                    pst.setString(2, fname);
                    pst.setString(3, lname);
                    pst.setString(4, v_age);
                    pst.setString(5, v_nationality);
                    pst.setString(6, add);
                    pst.setString(7, ph_no);
                    pst.setString(8, alt_phno);
                    pst.setString(9, jid);
                    pst.setString(10, cid);
                    // to add records in db table
                    pst.executeUpdate();
                    //popup msg for added record
                    JOptionPane.showMessageDialog(null, "Record added !");
                    load_table();
                    emptyFields();
                }
                catch(SQLException e1){
                    e1.printStackTrace();
                }
            }
        });
        btnsearch.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{
                    // statement to search particular id's data
                    String id = textsearch.getText();
                    pst = conn.prepareStatement("select * from Victim_Info where Victim_id = ?");
                    pst.setString(1, id);
                    ResultSet rs = pst.executeQuery();

                    if(rs.next() == true){

                        // retrieve the data from table and assign it to variable

                        String Victim_id = rs.getString(1);
                        String First_name = rs.getString(2);
                        String Last_name = rs.getString(3);
                        String Age = rs.getString(4);
                        String Nationality = rs.getString(5);
                        String Add = rs.getString(6);
                        String Phone_no = rs.getString(7);
                        String Alt_phno = rs.getString(8);
                        String Judge_id = rs.getString(9);
                        String Court_id = rs.getString(10);

                        //to display the records in text field

                        textvid.setText(Victim_id);
                        textfname.setText(First_name);
                        textlname.setText(Last_name);
                        textage.setText(Age);
                        textnationality.setText(Nationality);
                        textadd.setText(Add);
                        textphno.setText(Phone_no);
                        textaltphno.setText(Alt_phno);
                        textjid.setText(Judge_id);
                        textcid.setText(Court_id);

                    }
                    else{
                        emptyFields();
                        JOptionPane.showMessageDialog(null, "Invalid id selection !");
                    }
                }
                catch(SQLException ex){
                    ex.printStackTrace();
                }
            }
        });
        btnupdate.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String vid, fname, lname, vage, nationality, vadd, phone_no, alt_no, jid, cid;
                // assigning values to above created varibale from ui
                vid = textvid.getText();
                fname = textfname.getText();
                lname = textlname.getText();
                vage = textage.getText();
                nationality = textnationality.getText();
                vadd = textadd.getText();
                phone_no = textphno.getText();
                alt_no = textaltphno.getText();
                jid = textjid.getText();
                cid = textcid.getText();

                try{
                    //statement to update the values
                    pst = conn.prepareStatement("update Victim_Info set First_name = ?, Last_name = ?, age = ?, Nationality = ?, Address = ?, Phone_no = ?, Alternate_phone_no = ?, Judge_id = ?, Court_id = ? where Victim_id = ?");
                    System.out.println(pst);
                    System.out.println(vid);
                    // inserting column data of sql

                    pst.setString(1, fname);
                    pst.setString(2, lname);
                    pst.setString(3, vage);
                    pst.setString(4, nationality);
                    pst.setString(5, vadd);
                    pst.setString(6, phone_no);
                    pst.setString(7, alt_no);
                    pst.setString(8, jid);
                    pst.setString(9, cid);
                    pst.setString(10, vid);
                    // to add records in db table
                    pst.executeUpdate();
                    JOptionPane.showMessageDialog(null,"Records updated !");
                    load_table();

                    emptyFields();
                }
                catch(SQLException ex){
                    ex.printStackTrace();
                }
            }
        });
        btndelete.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String v_id;
                v_id = textvid.getText();

                try{
                    // statement to delete the record
                    pst = conn.prepareStatement("delete from Victim_info where Victim_id = ?");
                    pst.setString(1, v_id);
                    pst.executeUpdate();
                    JOptionPane.showMessageDialog(null,"Record deleted !");
                    load_table();
                    emptyFields();
                }
                catch(SQLException ex){
                    ex.printStackTrace();
                }
            }
        });
    }
}
