public class MaxHeap {
    private int[] heap;
    private int size;
    private int capacity;

    public MaxHeap(int capacity) {
        this.capacity = capacity;
        this.size = 0;
        this.heap = new int[capacity + 1]; // Index 0 is not used for simplicity
    }

    // Method to insert a new element into the max-heap
    public void insert(int element) {
        if (size == capacity) {
            System.out.println("Heap is full. Cannot insert element.");
            return;
        }

        size++;
        heap[size] = element;
        heapifyUp(size);
    }

    // Method to delete the maximum element from the max-heap
    public int deleteMax() {
        if (size == 0) {
            System.out.println("Heap is empty. Cannot delete maximum element.");
            return -1; // Assuming -1 represents an invalid value
        }

        int max = heap[1];
        heap[1] = heap[size];
        size--;
        heapifyDown(1);

        return max;
    }

    // Method to retrieve the maximum element without removing it
    public int getMax() {
        if (size == 0) {
            System.out.println("Heap is empty. No maximum element.");
            return -1; // Assuming -1 represents an invalid value
        }

        return heap[1];
    }

    // Helper method to maintain max-heap property while inserting
    private void heapifyUp(int index) {
        while (index > 1 && heap[index] > heap[parent(index)]) {
            swap(index, parent(index));
            index = parent(index);
        }
    }

    // Helper method to maintain max-heap property while deleting
    private void heapifyDown(int index) {
        int maxChildIndex = getMaxChildIndex(index);

        while (maxChildIndex != -1 && heap[index] < heap[maxChildIndex]) {
            swap(index, maxChildIndex);
            index = maxChildIndex;
            maxChildIndex = getMaxChildIndex(index);
        }
    }

    // Helper method to find the index of the maximum child
    private int getMaxChildIndex(int index) {
        int leftChild = leftChild(index);
        int rightChild = rightChild(index);

        if (leftChild <= size && rightChild <= size) {
            return (heap[leftChild] > heap[rightChild]) ? leftChild : rightChild;
        } else if (leftChild <= size) {
            return leftChild;
        } else if (rightChild <= size) {
            return rightChild;
        } else {
            return -1; // No child exists
        }
    }

    // Helper method to get the parent index of a given index
    private int parent(int index) {
        return index / 2;
    }

    // Helper method to get the left child index of a given index
    private int leftChild(int index) {
        return 2 * index;
    }

    // Helper method to get the right child index of a given index
    private int rightChild(int index) {
        return 2 * index + 1;
    }

    // Helper method to swap elements at two indices in the heap
    private void swap(int index1, int index2) {
        int temp = heap[index1];
        heap[index1] = heap[index2];
        heap[index2] = temp;
    }

    public static void main(String[] args) {
        MaxHeap maxHeap = new MaxHeap(10);

        maxHeap.insert(5);
        maxHeap.insert(3);
        maxHeap.insert(8);
        maxHeap.insert(1);
        maxHeap.insert(7);

        System.out.println("Max Ele: " + maxHeap.getMax());

        maxHeap.deleteMax();
        System.out.println("Max Ele after deletion: " + maxHeap.getMax());
    }
}

