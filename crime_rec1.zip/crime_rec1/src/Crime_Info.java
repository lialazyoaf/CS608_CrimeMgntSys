import net.proteanit.sql.DbUtils;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class Crime_Info {
    private JPanel main;
    private JTextField textcid;
    private JTextField textctype;
    private JTextField textwu;
    private JTextField textcd;
    private JTextField textct;
    private JTextField textcl;
    private JTextField textcrid;
    private JTextField textvid;
    private JButton btnupdate;
    private JButton btndelete;
    private JButton btnsave;
    private JButton btnsearch;
    private JTable table1;
    private JTextField textsearch;
    private JLabel Crime_id;
    private JLabel Crime_type;
    private JLabel Weapon_used;
    private JLabel Crime_date;
    private JLabel Crime_time;
    private JLabel Crime_loc;
    private JLabel Criminal_id;
    private JLabel Victim_id;

    public static void main(String[] args) {
        JFrame frame = new JFrame("Crime_Info");
        frame.setContentPane(new Crime_Info().main);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }

    // database connection

    Connection conn;
    PreparedStatement pst;
    public void connect(){
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/Crime_Record_Management", "root", "Ansh@123");
            System.out.println("Success Mysql connection");
        }
        catch (ClassNotFoundException ex){
            System.out.println(ex);
        }
        catch (SQLException ex){
            System.out.println(ex);
        }

    }

    // to load data in ui table (method)
    void load_table(){
        try{
            pst = conn.prepareStatement("select* from Crime_Info");
            ResultSet rs = pst.executeQuery();
            table1.setModel(DbUtils.resultSetToTableModel(rs)); // private JTable judge_table;
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }

    }

    // empty field method
    void emptyFields(){
        textcid.setText(" ");
        textctype.setText(" ");
        textwu.setText(" ");
        textcd.setText(" ");
        textct.setText(" ");
        textcl.setText(" ");
        textvid.setText(" ");
        textcrid.setText(" ");
        textcid.requestFocus();
    }

    public Crime_Info() {
        connect();
        load_table();
        btnsave.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // creating variables for storing inserting data
                String cid, ctype, weap_used, c_date, c_time, c_loc, crid, vid;
                // assigning values to above created varibale from ui
                cid = textcid.getText();
                ctype = textct.getText();
                weap_used = textwu.getText();
                c_date = textcd.getText();
                c_time = textct.getText();
                c_loc = textcl.getText();
                crid = textcrid.getText();
                vid = textvid.getText();

                try{
                    //insert statement for sql
                    pst = conn.prepareStatement("insert into Crime_Info( Crime_id, Crime_type, Weapon_used, crime_date, crime_time, Crime_location, Criminal_id, Victim_id) values(?,?,?,?,?,?,?,?)");
                    // assigning values to index number
                    pst.setString(1, cid);
                    pst.setString(2, ctype);
                    pst.setString(3, weap_used);
                    pst.setString(4, c_date);
                    pst.setString(5, c_time);
                    pst.setString(6, c_loc);
                    pst.setString(7, crid);
                    pst.setString(8, vid);
                    // to add records in db table
                    pst.executeUpdate();
                    //popup msg for added record
                    JOptionPane.showMessageDialog(null, "Record added !");
                    load_table();
                    emptyFields();
                }
                catch(SQLException e1){
                    e1.printStackTrace();
                }
            }
        });
        btnsearch.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{
                    // statement to search particular id's data
                    String id = textsearch.getText();
                    pst = conn.prepareStatement("select * from Crime_Info where Crime_id = ?");
                    pst.setString(1, id);
                    ResultSet rs = pst.executeQuery();

                    if(rs.next() == true){

                        // retrieve the data from table and assign it to variable
                        String Crime_id = rs.getString(1);
                        String Crime_type = rs.getString(2);
                        String Weapon_used = rs.getString(3);
                        String Crime_date = rs.getString(4);
                        String Crime_time = rs.getString(5);
                        String Crime_location = rs.getString(6);
                        String Criminal_id = rs.getString(7);
                        String Victim_id = rs.getString(8);

                        //to display the records in text field

                        textcid.setText(Crime_id);
                        textctype.setText(Crime_type);
                        textwu.setText(Weapon_used);
                        textcd.setText(Crime_date);
                        textct.setText(Crime_time);
                        textcl.setText(Crime_location);
                        textcrid.setText(Criminal_id);
                        textvid.setText(Victim_id);
                    }
                    else{
                        emptyFields();
                        JOptionPane.showMessageDialog(null, "Invalid id selection !");
                    }
                }
                catch(SQLException ex){
                    ex.printStackTrace();
                }
            }
        });
        btnupdate.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String cid, c_type, weap_used, c_date, c_time, c_loc, crid, vid;
                // assigning values to above created varibale from ui
                cid = textcid.getText();
                c_type = textctype.getText();
                weap_used = textwu.getText();
                c_date = textcd.getText();
                c_time = textct.getText();
                c_loc = textcl.getText();
                crid = textcrid.getText();
                vid = textvid.getText();

                try{
                    //statement to update the values
                    pst = conn.prepareStatement("update Crime_Info set Crime_type = ?, Weapon_used = ?, Crime_date = ?, Crime_time = ?, Crime_location = ?, Criminal_id = ?, Victim_id = ? where Crime_id = ?");
                    System.out.println(pst);
                    System.out.println(crid);
                    // inserting column data of sql

                    pst.setString(1, c_type);
                    pst.setString(2, weap_used);
                    pst.setString(3, c_date);
                    pst.setString(4, c_time);
                    pst.setString(5, c_loc);
                    pst.setString(6, crid);
                    pst.setString(7, vid);
                    pst.setString(8, cid);

                    // to add records in db table
                    pst.executeUpdate();
                    JOptionPane.showMessageDialog(null,"Records updated !");
                    load_table();

                    emptyFields();
                }
                catch(SQLException ex){
                    ex.printStackTrace();
                }
            }
        });
        btndelete.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String c_id;
                c_id = textcid.getText();

                try{
                    // statement to delete the record
                    pst = conn.prepareStatement("delete from Crime_Info where Crime_id = ?");
                    pst.setString(1, c_id);
                    pst.executeUpdate();
                    JOptionPane.showMessageDialog(null,"Record deleted !");
                    load_table();
                    emptyFields();
                }
                catch(SQLException ex){
                    ex.printStackTrace();
                }
            }
        });
    }
}
