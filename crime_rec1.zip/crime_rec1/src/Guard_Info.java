import net.proteanit.sql.DbUtils;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class Guard_Info {
    private JPanel main;
    private JTextField textgid;
    private JTextField textfn;
    private JTextField textln;
    private JTextField textg;
    private JTextField textdob;
    private JTextField textadd;
    private JTextField textphno;
    private JTextField textaltphno;
    private JTextField textst;
    private JTextField textpid;
    private JButton btnupdate;
    private JButton btndelete;
    private JButton btnsave;
    private JButton btnsearch;
    private JTable table1;
    private JTextField textsearch;
    private JLabel Guard_id;
    private JLabel First_name;
    private JLabel Last_name;
    private JLabel Gender;
    private JLabel Dob;
    private JLabel Address;
    private JLabel Phone_no;
    private JLabel Alt_phno;
    private JLabel Shift_timing;
    private JLabel Prison_id;

    public static void main(String[] args) {
        JFrame frame = new JFrame("Guard_Info");
        frame.setContentPane(new Guard_Info().main);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }

    // database connection

    Connection conn;
    PreparedStatement pst;
    public void connect(){
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/Crime_Record_Management", "root", "Ansh@123");
            System.out.println("Success Mysql connection");
        }
        catch (ClassNotFoundException ex){
            System.out.println(ex);
        }
        catch (SQLException ex){
            System.out.println(ex);
        }

    }

    // to load data in ui table (method)
    void load_table(){
        try{
            pst = conn.prepareStatement("select* from Guard_Info");
            ResultSet rs = pst.executeQuery();
            table1.setModel(DbUtils.resultSetToTableModel(rs)); // private JTable judge_table;
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }

    }

    // empty field method
    void emptyFields(){
        textgid.setText(" ");
        textfn.setText(" ");
        textln.setText(" ");
        textg.setText(" ");
        textdob.setText(" ");
        textadd.setText(" ");
        textphno.setText(" ");
        textaltphno.setText(" ");
        textst.setText(" ");
        textpid.setText(" ");
        textfn.requestFocus();
    }


    public Guard_Info() {
        connect();
        load_table();
        btnsave.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // creating variables for storing inserting data
                String gid, fname, lname, g_gender, g_dob, add, ph_no, alt_phno, shift_t, pid;
                // assigning values to above created varibale from ui
                gid = textgid.getText();
                fname = textfn.getText();
                lname = textln.getText();
                g_gender = textg.getText();
                g_dob = textdob.getText();
                add = textadd.getText();
                ph_no = textphno.getText();
                alt_phno = textaltphno.getText();
                shift_t = textst.getText();
                pid = textpid.getText();

                try{
                    //insert statement for sql
                    pst = conn.prepareStatement("insert into Guard_Info(Guard_id, First_name, Last_name, Gender, DOB, Address, Phone_no, Alternate_phone_no, Shift_timing, Prison_id) values(?,?,?,?,?,?,?,?,?,?)");
                    // assigning values to index number
                    pst.setString(1, gid);
                    pst.setString(2, fname);
                    pst.setString(3, lname);
                    pst.setString(4, g_gender);
                    pst.setString(5, g_dob);
                    pst.setString(6, add);
                    pst.setString(7, ph_no);
                    pst.setString(8, alt_phno);
                    pst.setString(9, shift_t);
                    pst.setString(10, pid);
                    // to add records in db table
                    pst.executeUpdate();
                    //popup msg for added record
                    JOptionPane.showMessageDialog(null, "Record added !");
                    load_table();
                    emptyFields();
                }
                catch(SQLException e1){
                    e1.printStackTrace();
                }
            }
        });
        btnsearch.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{
                    // statement to search particular id's data
                    String id = textsearch.getText();
                    pst = conn.prepareStatement("select * from Guard_Info where Guard_id = ?");
                    pst.setString(1, id);
                    ResultSet rs = pst.executeQuery();

                    if(rs.next() == true){

                        // retrieve the data from table and assign it to variable

                        String Guard_id = rs.getString(1);
                        String First_name = rs.getString(2);
                        String Last_name = rs.getString(3);
                        String Gender = rs.getString(4);
                        String Dob = rs.getString(5);
                        String Address = rs.getString(6);
                        String Phone_no = rs.getString(7);
                        String Alt_phno = rs.getString(8);
                        String Shift_timing = rs.getString(9);
                        String Prison_id = rs.getString(10);

                        //to display the records in text field

                        textgid.setText(Guard_id);
                        textfn.setText(First_name);
                        textln.setText(Last_name);
                        textg.setText(Gender);
                        textdob.setText(Dob);
                        textadd.setText(Address);
                        textphno.setText(Phone_no);
                        textaltphno.setText(Alt_phno);
                        textst.setText(Shift_timing);
                        textpid.setText(Prison_id);

                    }
                    else{
                        emptyFields();
                        JOptionPane.showMessageDialog(null, "Invalid id selection !");
                    }
                }
                catch(SQLException ex){
                    ex.printStackTrace();
                }
            }
        });
        btnupdate.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String gid, fname, lname, gen, dob, gadd, phone_no, alt_no, s_time, pid;
                // assigning values to above created varibale from ui
                gid = textgid.getText();
                fname = textfn.getText();
                lname = textln.getText();
                gen = textg.getText();
                dob = textdob.getText();
                gadd = textadd.getText();
                phone_no = textphno.getText();
                alt_no = textaltphno.getText();
                s_time = textst.getText();
                pid = textpid.getText();

                try{
                    //statement to update the values
                    pst = conn.prepareStatement("update Guard_Info set First_name = ?, Last_name = ?, Gender = ?, DOB = ?, Address = ?, Phone_no = ?, Alternate_phone_no = ?, Shift_timing = ?, Prison_id = ? where Guard_id = ?");
                    System.out.println(pst);
                    System.out.println(gid);
                    // inserting column data of sql

                    pst.setString(1, fname);
                    pst.setString(2, lname);
                    pst.setString(3, gen);
                    pst.setString(4, dob);
                    pst.setString(5, gadd);
                    pst.setString(6, phone_no);
                    pst.setString(7, alt_no);
                    pst.setString(8, s_time);
                    pst.setString(9, pid);
                    pst.setString(10, gid);
                    // to add records in db table
                    pst.executeUpdate();
                    JOptionPane.showMessageDialog(null,"Records updated !");
                    load_table();

                    emptyFields();
                }
                catch(SQLException ex){
                    ex.printStackTrace();
                }
            }
        });
        btndelete.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String g_id;
                g_id = textgid.getText();

                try{
                    // statement to delete the record
                    pst = conn.prepareStatement("delete from Guard_info where Guard_id = ?");
                    pst.setString(1, g_id);
                    pst.executeUpdate();
                    JOptionPane.showMessageDialog(null,"Record deleted !");
                    load_table();
                    emptyFields();
                }
                catch(SQLException ex){
                    ex.printStackTrace();
                }
            }
        });
    }
}
