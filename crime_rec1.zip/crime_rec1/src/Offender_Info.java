import net.proteanit.sql.DbUtils;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class Offender_Info {
    private JPanel main;
    private JTextField textcrid;
    private JTextField textfname;
    private JTextField textlname;
    private JTextField textgender;
    private JTextField textage;
    private JTextField textnationality;
    private JTextField textadd;
    private JTextField textphno;
    private JTextField textot;
    private JTextField textbs;
    private JTextField textjt;
    private JTextField textpl;
    private JTextField textpg;
    private JTextField textvid;
    private JTextField textjid;
    private JTextField textcid;
    private JTextField textaltphno;
    private JTable table1;
    private JButton btnupdate;
    private JButton btndelete;
    private JButton btnsave;
    private JButton btnsearch;
    private JTextField textsearch;
    private JLabel Criminal_id;
    private JLabel First_name;
    private JLabel Last_name;
    private JLabel Gender;
    private JLabel Age;
    private JLabel Nationality;
    private JLabel Add;
    private JLabel Phone_no;
    private JLabel Alt_phone_no;
    private JLabel Offense_type;
    private JLabel Bail_status;
    private JLabel Jail_terms;
    private JLabel Prison_loc;
    private JLabel Prison_guard;
    private JLabel Victim_id;
    private JLabel Judge_id;
    private JLabel Court_id;


    public static void main(String[] args) {
        JFrame frame = new JFrame("Offender_Info");
        frame.setContentPane(new Offender_Info().main);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }

    // database connection

    Connection conn;
    PreparedStatement pst;
    public void connect(){
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/Crime_Record_Management", "root", "Ansh@123");
            System.out.println("Success Mysql connection");
        }
        catch (ClassNotFoundException ex){
            System.out.println(ex);
        }
        catch (SQLException ex){
            System.out.println(ex);
        }

    }

    // to load data in ui table (method)
    void load_table(){
        try{
            pst = conn.prepareStatement("select* from Offender_Info");
            ResultSet rs = pst.executeQuery();
            table1.setModel(DbUtils.resultSetToTableModel(rs)); // private JTable judge_table;
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }

    }

    void emptyFields(){
        textcrid.setText(" ");
        textfname.setText(" ");
        textlname.setText(" ");
        textgender.setText(" ");
        textage.setText(" ");
        textnationality.setText(" ");
        textadd.setText(" ");
        textphno.setText(" ");
        textaltphno.setText(" ");
        textot.setText(" ");
        textbs.setText(" ");
        textjt.setText(" ");
        textpl.setText(" ");
        textpg.setText(" ");
        textvid.setText(" ");
        textjid.setText(" ");
        textcid.setText(" ");
        textfname.requestFocus();
    }

    public Offender_Info() {
        connect();
        load_table();
        btnsave.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // creating variables for storing inserting data
                String crid, fname, lname, o_gender, o_age, o_nationality, add, ph_no, alt_phno, ot, bs, jt, pl, pg, vid, jid, cid;
                // assigning values to above created varibale from ui
                crid = textcrid.getText();
                fname = textfname.getText();
                lname = textlname.getText();
                o_gender = textgender.getText();
                o_age = textage.getText();
                o_nationality = textnationality.getText();
                add = textadd.getText();
                ph_no = textphno.getText();
                alt_phno = textaltphno.getText();
                ot = textot.getText();
                bs = textbs.getText();
                jt = textjt.getText();
                pl = textpl.getText();
                pg = textpg.getText();
                vid = textvid.getText();
                jid = textjid.getText();
                cid = textcid.getText();

                try{
                    //insert statement for sql
                    pst = conn.prepareStatement("insert into Offender_Info( Criminal_id, First_name, Last_name, Gender, age, Nationality, Address, Phone_no, alternate_phone_no, Offense_type, Bail_status, Jail_terms, Prison_location, Prison_guard, Victim_id, Judge_id, Court_id) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
                    // assigning values to index number
                    pst.setString(1, crid);
                    pst.setString(2, fname);
                    pst.setString(3, lname);
                    pst.setString(4, o_gender);
                    pst.setString(5, o_age);
                    pst.setString(6, o_nationality);
                    pst.setString(7, add);
                    pst.setString(8, ph_no);
                    pst.setString(9, alt_phno);
                    pst.setString(10, ot);
                    pst.setString(11, bs);
                    pst.setString(12, jt);
                    pst.setString(13, pl);
                    pst.setString(14, pg);
                    pst.setString(15, vid);
                    pst.setString(16, jid);
                    pst.setString(17, cid);
                    // to add records in db table
                    pst.executeUpdate();
                    //popup msg for added record
                    JOptionPane.showMessageDialog(null, "Record added !");
                    load_table();
                    emptyFields();
                }
                catch(SQLException e1){
                    e1.printStackTrace();
                }
            }
        });
        btnsearch.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{
                    // statement to search particular id's data
                    String id = textsearch.getText();
                    pst = conn.prepareStatement("select * from Offender_Info where Criminal_id = ?");
                    pst.setString(1, id);
                    ResultSet rs = pst.executeQuery();

                    if(rs.next() == true){

                        // retrieve the data from table and assign it to variable
                        String Criminal_id = rs.getString(1);
                        String First_name = rs.getString(2);
                        String Last_name = rs.getString(3);
                        String Gender = rs.getString(4);
                        String Age = rs.getString(5);
                        String Nationality = rs.getString(6);
                        String Add = rs.getString(7);
                        String Phone_no = rs.getString(8);
                        String Alt_phone_no = rs.getString(9);
                        String Offense_type = rs.getString(10);
                        String Bail_status = rs.getString(11);
                        String Jail_terms = rs.getString(12);
                        String Prison_loc = rs.getString(13);
                        String Prison_guard = rs.getString(14);
                        String Victim_id = rs.getString(15);
                        String Judge_id = rs.getString(16);
                        String Court_id = rs.getString(17);

                        //to display the records in text field

                        textcrid.setText(Criminal_id);
                        textfname.setText(First_name);
                        textlname.setText(Last_name);
                        textgender.setText(Gender);
                        textage.setText(Age);
                        textnationality.setText(Nationality);
                        textadd.setText(Add);
                        textphno.setText(Phone_no);
                        textaltphno.setText(Alt_phone_no);
                        textot.setText(Offense_type);
                        textbs.setText(Bail_status);
                        textjt.setText(Jail_terms);
                        textpl.setText(Prison_loc);
                        textpg.setText(Prison_guard);
                        textvid.setText(Victim_id);
                        textjid.setText(Judge_id);
                        textcid.setText(Court_id);

                    }
                    else{
                        emptyFields();
                        JOptionPane.showMessageDialog(null, "Invalid id selection !");
                    }
                }
                catch(SQLException ex){
                    ex.printStackTrace();
                }
            }
        });
        btnupdate.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String crid, fname, lname, gender, oage, nationality, oadd, phone_no, alt_no, ot, bs, jt, pl, pg, vid, jid, cid;
                // assigning values to above created varibale from ui
                crid = textcrid.getText();
                fname = textfname.getText();
                lname = textlname.getText();
                gender = textgender.getText();
                oage = textage.getText();
                nationality = textnationality.getText();
                oadd = textadd.getText();
                phone_no = textphno.getText();
                alt_no = textaltphno.getText();
                ot = textot.getText();
                bs = textbs.getText();
                jt = textjt.getText();
                pl = textpl.getText();
                pg = textpg.getText();
                vid = textvid.getText();
                jid = textjid.getText();
                cid = textcid.getText();

                try{
                    //statement to update the values
                    pst = conn.prepareStatement("update Offender_Info set First_name = ?, Last_name = ?, Gender = ?, age = ?, Nationality = ?, Address = ?, Phone_no = ?, Alternate_phone_no = ?, Offense_type = ?, Bail_status = ?, Jail_terms = ?, Prison_location = ?, Prison_guard = ?, Victim_id = ?, Judge_id = ?, Court_id = ? where Criminal_id = ?");
                    System.out.println(pst);
                    System.out.println(crid);
                    // inserting column data of sql

                    pst.setString(1, fname);
                    pst.setString(2, lname);
                    pst.setString(3, gender);
                    pst.setString(4, oage);
                    pst.setString(5, nationality);
                    pst.setString(6, oadd);
                    pst.setString(7, phone_no);
                    pst.setString(8, alt_no);
                    pst.setString(9, ot);
                    pst.setString(10, bs);
                    pst.setString(11, jt);
                    pst.setString(12, pl);
                    pst.setString(13, pg);
                    pst.setString(14, vid);
                    pst.setString(15, jid);
                    pst.setString(16, cid);
                    pst.setString(17, crid);

                    // to add records in db table
                    pst.executeUpdate();
                    JOptionPane.showMessageDialog(null,"Records updated !");
                    load_table();

                    emptyFields();
                }
                catch(SQLException ex){
                    ex.printStackTrace();
                }
            }
        });
        btndelete.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String cr_id;
                cr_id = textcrid.getText();

                try{
                    // statement to delete the record
                    pst = conn.prepareStatement("delete from Offender_Info where Criminal_id = ?");
                    pst.setString(1, cr_id);
                    pst.executeUpdate();
                    JOptionPane.showMessageDialog(null,"Record deleted !");
                    load_table();
                    emptyFields();
                }
                catch(SQLException ex){
                    ex.printStackTrace();
                }
            }
        });
    }
}
