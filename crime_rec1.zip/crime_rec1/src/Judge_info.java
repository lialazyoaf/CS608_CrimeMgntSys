import net.proteanit.sql.DbUtils;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class Judge_info {
    private JLabel Judge_id;
    private JLabel Judge_age;
    private JLabel First_name;
    private JLabel Last_name;
    private JLabel Designation;
    private JLabel Court_id;
    private JTextField textjid;
    private JTextField textage;
    private JTextField textfname;
    private JTextField textlname;
    private JTextField textdes;
    private JTextField textcid;
    private JButton btndelete;
    private JButton btnupdate;
    private JButton btnsave;
    private JButton btnsearch;
    private JTextField textsearch;
    private JTable judge_table;
    private JPanel main;

    public static void main(String[] args) {
        JFrame frame = new JFrame("Judge_info");
        frame.setContentPane(new Judge_info().main);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }

    // databasq connection

    Connection conn;
    PreparedStatement pst;
    public void connect(){
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/Crime_Record_Management", "root", "Ansh@123");
            System.out.println("Success Mysql connection");
        }
        catch (ClassNotFoundException ex){
            System.out.println(ex);
        }
        catch (SQLException ex){
            System.out.println(ex);
        }

    }

    // to load data in ui table (method)
    void load_table(){
        try{
            pst = conn.prepareStatement("select* from Judge_Info");
            ResultSet rs = pst.executeQuery();
            judge_table.setModel(DbUtils.resultSetToTableModel(rs)); // private JTable judge_table;
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }

    }

    //empty the fields from ui after insertion of data (method)

    void emptyFields(){
        textjid.setText(" ");
        textage.setText(" ");
        textfname.setText(" ");
        textlname.setText(" ");
        textdes.setText(" ");
        textcid.setText(" ");
        textfname.requestFocus();
    }


    public Judge_info() {
        connect();
        load_table();
        btnsave.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // creating variables for storing inserting data
                String jid, jage, fname, lname, designation, cid;
                // assigning values to above created varibale from ui
                jid = textjid.getText();
                jage = textage.getText();
                fname = textfname.getText();
                lname = textlname.getText();
                designation = textdes.getText();
                cid = textcid.getText();

                try{
                    //insert statement for sql
                    pst = conn.prepareStatement("insert into Judge_Info(Judge_id, Judge_age, First_name, Last_name, Designation, Court_id) values(?,?,?,?,?,?)");
                    // assigning values to index number
                    pst.setString(1, jid);
                    pst.setString(2, jage);
                    pst.setString(3, fname);
                    pst.setString(4, lname);
                    pst.setString(5, designation);
                    pst.setString(6, cid);
                    // to add records in db table
                    pst.executeUpdate();
                    //popup msg for added record
                    JOptionPane.showMessageDialog(null, "Record added !");
                                            load_table();
                                            emptyFields();
                }
                catch(SQLException e1){
                    e1.printStackTrace();
                }


            }
        });
        btnsearch.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{
                    // statement to search particular id's data
                    String id = textsearch.getText();
                    pst = conn.prepareStatement("select * from Judge_Info where Judge_id = ?");
                    pst.setString(1, id);
                    ResultSet rs = pst.executeQuery();

                    if(rs.next() == true){

                        // retrieve the data from table and assign it to variable

                        String Judge_id = rs.getString(1);
                        String Judge_age = rs.getString(2);
                        String First_name = rs.getString(3);
                        String Last_name = rs.getString(4);
                        String Designation = rs.getString(5);
                        String Court_id = rs.getString(6);

                        //to display the records in text field

                        textjid.setText(Judge_id);
                        textage.setText(Judge_age);
                        textfname.setText(First_name);
                        textlname.setText(Last_name);
                        textdes.setText(Designation);
                        textcid.setText(Court_id);
                    }
                    else{
                        emptyFields();
                        JOptionPane.showMessageDialog(null, "Invalid id selection !");
                    }
                }
                catch(SQLException ex){
                    ex.printStackTrace();
                }
            }
        });
        btnupdate.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String jid, jage, fname, lname, designation, cid;
                // assigning values to above created varibale from ui
                jid = textjid.getText();
                jage = textage.getText();
                fname = textfname.getText();
                lname = textlname.getText();
                designation = textdes.getText();
                cid = textcid.getText();

                try{
                    //statement to update the values
                    pst = conn.prepareStatement("update Judge_Info set Judge_age = ?, First_name = ?, Last_name = ?, Designation = ?, Court_id = ? where Judge_id = ?");
                    System.out.println(pst);
                    System.out.println(jid);
                    // inserting column data of sql
                    pst.setString(1, jage);
                    pst.setString(2, fname);
                    pst.setString(3, lname);
                    pst.setString(4, designation);
                    pst.setString(5, cid);
                    pst.setString(6, jid);
                    // to add records in db table
                    pst.executeUpdate();
                    JOptionPane.showMessageDialog(null,"Records updated !");
                    load_table();

                    emptyFields();
                }
                catch(SQLException ex){
                    ex.printStackTrace();
                }
            }
        });
        btndelete.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String j_id;
                j_id = textjid.getText();

                try{
                    // statement to delete the record
                    pst = conn.prepareStatement("delete from Judge_info where Judge_id = ?");
                    pst.setString(1, j_id);
                    pst.executeUpdate();
                    JOptionPane.showMessageDialog(null,"Record deleted !");
                    load_table();
                    emptyFields();
                }
                catch(SQLException ex){
                    ex.printStackTrace();
                }
            }
        });
    }
}
